# Changelog
## v1.0.1
- Fixed a bug where Spectating would not hide after exiting Clean Mode.

## v1.0.0 
- The first beta release of the mod